# Cost, dev

## Cost

Space is the stored dense index. Computation is the number of query–passage scores.
Wall time is retrieval plus rerank, including the model load, and GPU peak is
PyTorch reserved memory. A dash means that run was written before this was recorded.

| Run | First stage | Rerank | Stored index | GPU peak | Wall time |
| --- | --- | --- | ---: | ---: | ---: |
| title · BM25 | 3,775,326 BM25 scores | — | — | — | — |
| title · BM25 · cross | 3,775,326 BM25 scores | 19,200 cross-encoder pairs | — | — | — |
| title · BM25 · late | 3,775,326 BM25 scores | 19,200 MaxSim pairs | — | — | — |
| title · dense | 9,122,112 dot products | — | 70 MB | — | — |
| title · dense · cross | 9,122,112 dot products | 19,200 cross-encoder pairs | 70 MB | — | — |
| title · dense · late | 9,122,112 dot products | 19,200 MaxSim pairs | 70 MB | — | — |
| rewrite · BM25 | 40,510,444 BM25 scores (2,065 strings) | — | — | — | — |
| rewrite · BM25 · cross | 40,510,444 BM25 scores (2,065 strings) | 19,200 cross-encoder pairs | — | — | — |
| rewrite · BM25 · late | 40,510,444 BM25 scores (2,065 strings) | 19,200 MaxSim pairs | — | — | — |
| rewrite · dense | 98,110,215 dot products (2,065 strings) | — | 70 MB | — | — |
| rewrite · dense · cross | 98,110,215 dot products (2,065 strings) | 19,200 cross-encoder pairs | 70 MB | — | — |
| rewrite · dense · late | 98,110,215 dot products (2,065 strings) | 19,200 MaxSim pairs | 70 MB | — | — |
| late only | 3,775,326 MaxSim, 38,595 passages encoded | — | — | — | — |
| title · BM25 · late · k200 | 3,775,326 BM25 scores | 38,400 MaxSim pairs | — | — | — |
| title · dense · late · k200 | 9,122,112 dot products | 38,400 MaxSim pairs | 70 MB | — | — |
| disproof · BM25 | 7,486,909 BM25 scores (381 strings) | — | — | — | 8.1 s |
| disproof · dense | 18,101,691 dot products (381 strings) | — | 70 MB | 0.20 GB | 25.4 s |

Dense multiplies each search string by every stored chunk, then drops the other set.
BM25 and a late first stage score only the passages in the claim's set. The reranker
scores the original title against each kept passage. The dense index is one shared file.
BM25 builds its index in memory and does not save it. A late first stage encodes
passages for that run and does not save the vectors. Watts are not sampled.
